(*
  Print the current date

  Usage:
  ./now
*)

open Date
print stdout (now ());
print_newline ()
